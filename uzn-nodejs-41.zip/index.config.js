var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.config.js
var index_config_exports = {};
__export(index_config_exports, {
  default: () => index_config_default
});
module.exports = __toCommonJS(index_config_exports);
var index_config_default = {
  sites: [
    {
      key: "s01",
      name: "移动｜星源",
      type: 3,
      searchable: 1,
      url: "https://xy.183933.xyz/php/pt.php/provide/vod/",
      categories: []
    },
    {
      key: "s02",
      name: "酷我｜星源",
      type: 3,
      searchable: 1,
      url: "https://xy.183933.xyz/php/kuwo.php/provide/vod",
      categories: []
    },
    {
      key: "s03",
      name: "咪咕｜星源",
      type: 3,
      searchable: 1,
      url: "https://xy.183933.xyz/php/miguyy.php/provide/vod",
      categories: []
    },
    {
      key: "s04",
      name: "A站｜星源",
      type: 3,
      searchable: 1,
      url: "https://xy.183933.xyz/php/acfun.php/provide/vod",
      categories: []
    },
    {
      key: "s05",
      name: "小乐｜星源",
      type: 3,
      searchable: 1,
      url: "https://xy.183933.xyz/php/ls.php/vod",
      categories: []
    },
    {
      key: "s06",
      name: "影视 | 建安",
      type: 3,
      searchable: 1,
      url: "http://154.219.117.232:9981/jacloudapi.php/provide/vod",
      categories: []
    },
    {
      key: "s07",
      name: "🍀360资源",
      type: 3,
      searchable: 1,
      url: "https://360zy.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s08",
      name: "❤百度",
      type: 3,
      searchable: 1,
      url: "https://api.apibdzy.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s09",
      name: "🍀非凡API",
      type: 3,
      searchable: 1,
      url: "https://api.ffzyapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s10",
      name: "❤fox",
      type: 3,
      searchable: 1,
      url: "https://api.foxzyapi.com/api.php/provide/vod/?ac=list",
      categories: []
    },
    {
      key: "s11",
      name: "🍀光速资源",
      type: 3,
      searchable: 1,
      url: "https://api.guangsuapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s12",
      name: "api.maoyanapi.top",
      type: 3,
      searchable: 1,
      url: "https://api.maoyanapi.top/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s13",
      name: "🍀牛牛点播",
      type: 3,
      searchable: 1,
      url: "https://api.niuniuzy.me/api.php/provide/vod",
      categories: []
    },
    {
      key: "s14",
      name: "🍀U酷资源88",
      type: 3,
      searchable: 1,
      url: "https://api.ukuapi88.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s15",
      name: "🍀无尽CC",
      type: 3,
      searchable: 1,
      url: "https://api.wujinapi.cc/api.php/provide/vod",
      categories: []
    },
    {
      key: "s16",
      name: "🍀无尽资源",
      type: 3,
      searchable: 1,
      url: "https://api.wujinapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s17",
      name: "🍀无尽ME",
      type: 3,
      searchable: 1,
      url: "https://api.wujinapi.me/api.php/provide/vod",
      categories: []
    },
    {
      key: "s18",
      name: "🍀无尽NET",
      type: 3,
      searchable: 1,
      url: "https://api.wujinapi.net/api.php/provide/vod",
      categories: []
    },
    {
      key: "s19",
      name: "api.yyzy-tv.vip",
      type: 3,
      searchable: 1,
      url: "https://api.yyzy-tv.vip/inc/apijson.php",
      categories: []
    },
    {
      key: "s20",
      name: "🍀最大资源",
      type: 3,
      searchable: 1,
      url: "https://api.zuidapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s21",
      name: "🍀茅台资源",
      type: 3,
      searchable: 1,
      url: "https://caiji.maotaizy.cc/api.php/provide/vod",
      categories: []
    },
    {
      key: "s22",
      name: "🍀魔都动漫",
      type: 3,
      searchable: 1,
      url: "https://caiji.moduapi.cc/api.php/provide/vod",
      categories: []
    },
    {
      key: "s23",
      name: "🍀丫丫点播",
      type: 3,
      searchable: 1,
      url: "https://cj.yayazy.net/api.php/provide/vod",
      categories: []
    },
    {
      key: "s24",
      name: "❤ckzy",
      type: 3,
      searchable: 1,
      url: "https://ckzy.me/api.php/provide/vod/?ac=list",
      categories: []
    },
    {
      key: "s25",
      name: "🍀卧龙采集",
      type: 3,
      searchable: 1,
      url: "https://collect.wolongzyw.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s26",
      name: "影视 | 非凡[直连]",
      type: 3,
      searchable: 1,
      url: "http://ffzy.tv/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s27",
      name: "🍀非凡资源",
      type: 3,
      searchable: 1,
      url: "http://ffzy5.tv/api.php/provide/vod",
      categories: []
    },
    {
      key: "s28",
      name: "hhzyapi.com",
      type: 3,
      searchable: 1,
      url: "https://hhzyapi.com/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s29",
      name: "🍀红牛资源",
      type: 3,
      searchable: 1,
      url: "https://www.hongniuzy2.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s30",
      name: "🍀红牛资源3",
      type: 3,
      searchable: 1,
      url: "https://www.hongniuzy3.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s31",
      name: "huyaapi.com",
      type: 3,
      searchable: 1,
      url: "https://www.huyaapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s32",
      name: "🍀金鹰点播",
      type: 3,
      searchable: 1,
      url: "https://jinyingzy.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s33",
      name: "json02.heimuer.xyz",
      type: 3,
      searchable: 1,
      url: "https://json02.heimuer.xyz/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s34",
      name: "🍀极速资源",
      type: 3,
      searchable: 1,
      url: "https://jszyapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s35",
      name: "🍀鲸鱼资源",
      type: 3,
      searchable: 1,
      url: "https://jyzyapi.com/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s36",
      name: "lzizy1.com",
      type: 3,
      searchable: 1,
      url: "https://lzizy1.com/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s37",
      name: "❤天空资源",
      type: 3,
      searchable: 1,
      url: "https://m3u8.tiankongapi.com/api.php/provide/vod/from/tkm3u8/?ac=list",
      categories: []
    },
    {
      key: "s38",
      name: "🍀魔都资源",
      type: 3,
      searchable: 1,
      url: "https://www.mdzyapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s39",
      name: "mtzy.me",
      type: 3,
      searchable: 1,
      url: "https://mtzy.me/api.php/provide/vod/",
      categories: []
    },
    {
      key: "s40",
      name: "🍀閃電资源",
      type: 3,
      searchable: 1,
      url: "https://sdzyapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s41",
      name: "🍀天涯资源",
      type: 3,
      searchable: 1,
      url: "https://tyyszy.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s42",
      name: "🍀天涯海角",
      type: 3,
      searchable: 1,
      url: "https://tyyszyapi.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s43",
      name: "🍀卧龙资源",
      type: 3,
      searchable: 1,
      url: "https://wolongzyw.com/api.php/provide/vod",
      categories: []
    },
    {
      key: "s44",
      name: "ys.cxkjg.cn",
      type: 3,
      searchable: 1,
      url: "https://ys.cxkjg.cn/api/provide/vod/",
      categories: []
    },
    {
      key: "s45",
      name: "🍀最大点播",
      type: 3,
      searchable: 1,
      url: "http://zuidazy.me/api.php/provide/vod",
      categories: []
    }
  ],
  color: [
    {
      light: {
        bg: "https://i2.100024.xyz/2024/01/13/pptcej.webp",
        bgMask: "0x50ffffff",
        primary: "0xff446732",
        onPrimary: "0xffffffff",
        primaryContainer: "0xffc5efab",
        onPrimaryContainer: "0xff072100",
        secondary: "0xff55624c",
        onSecondary: "0xffffffff",
        secondaryContainer: "0xffd9e7cb",
        onSecondaryContainer: "0xff131f0d",
        tertiary: "0xff386666",
        onTertiary: "0xffffffff",
        tertiaryContainer: "0xffbbebec",
        onTertiaryContainer: "0xff002020",
        error: "0xffba1a1a",
        onError: "0xffffffff",
        errorContainer: "0xffffdad6",
        onErrorContainer: "0xff410002",
        background: "0xfff8faf0",
        onBackground: "0xff191d16",
        surface: "0xfff8faf0",
        onSurface: "0xff191d16",
        surfaceVariant: "0xffe0e4d6",
        onSurfaceVariant: "0xff191d16",
        inverseSurface: "0xff2e312b",
        inverseOnSurface: "0xfff0f2e7",
        outline: "0xff74796d",
        outlineVariant: "0xffc3c8bb",
        shadow: "0xff000000",
        scrim: "0xff000000",
        inversePrimary: "0xffaad291",
        surfaceTint: "0xff446732"
      },
      dark: {
        bg: "https://i2.100024.xyz/2024/01/13/pptg3z.webp",
        bgMask: "0x50000000",
        primary: "0xffaad291",
        onPrimary: "0xff173807",
        primaryContainer: "0xff2d4f1c",
        onPrimaryContainer: "0xffc5efab",
        secondary: "0xffbdcbb0",
        onSecondary: "0xff283420",
        secondaryContainer: "0xff3e4a35",
        onSecondaryContainer: "0xffd9e7cb",
        tertiary: "0xffa0cfcf",
        onTertiary: "0xff003738",
        tertiaryContainer: "0xff1e4e4e",
        onTertiaryContainer: "0xffbbebec",
        error: "0xffffb4ab",
        onError: "0xff690005",
        errorContainer: "0xff93000a",
        onErrorContainer: "0xffffdad6",
        background: "0xff11140e",
        onBackground: "0xffe1e4d9",
        surface: "0xff11140e",
        onSurface: "0xffe1e4d9",
        surfaceVariant: "0xff43483e",
        onSurfaceVariant: "0xffe1e4d9",
        inverseSurface: "0xffe1e4d9",
        inverseOnSurface: "0xff2e312b",
        outline: "0xff8d9286",
        outlineVariant: "0xff43483e",
        shadow: "0xff000000",
        scrim: "0xff000000",
        inversePrimary: "0xff446732",
        surfaceTint: "0xffaad291"
      }
    },
    {
      light: {
        bg: "https://i2.100024.xyz/2024/01/13/pi2rpw.webp",
        bgMask: "0x50ffffff",
        primary: "0xff666014",
        onPrimary: "0xffffffff",
        primaryContainer: "0xffeee58c",
        onPrimaryContainer: "0xff1f1c00",
        secondary: "0xff625f42",
        onSecondary: "0xffffffff",
        secondaryContainer: "0xffe9e4be",
        onSecondaryContainer: "0xff1e1c05",
        tertiary: "0xff3f6654",
        onTertiary: "0xffffffff",
        tertiaryContainer: "0xffc1ecd5",
        onTertiaryContainer: "0xff002114",
        error: "0xffba1a1a",
        onError: "0xffffffff",
        errorContainer: "0xffffdad6",
        onErrorContainer: "0xff410002",
        background: "0xfffef9eb",
        onBackground: "0xff1d1c14",
        surface: "0xfffef9eb",
        onSurface: "0xff1d1c14",
        surfaceVariant: "0xffe7e3d0",
        onSurfaceVariant: "0xff1d1c14",
        inverseSurface: "0xff323128",
        inverseOnSurface: "0xfff5f1e3",
        outline: "0xff7a7768",
        outlineVariant: "0xffcbc7b5",
        shadow: "0xff000000",
        scrim: "0xff000000",
        inversePrimary: "0xffd1c973",
        surfaceTint: "0xff666014"
      },
      dark: {
        bg: "https://i2.100024.xyz/2024/01/13/pi2reo.webp",
        bgMask: "0x50000000",
        primary: "0xffd1c973",
        onPrimary: "0xff353100",
        primaryContainer: "0xff4d4800",
        onPrimaryContainer: "0xffeee58c",
        secondary: "0xffcdc8a3",
        onSecondary: "0xff333117",
        secondaryContainer: "0xff4a482c",
        onSecondaryContainer: "0xffe9e4be",
        tertiary: "0xffa6d0b9",
        onTertiary: "0xff0e3727",
        tertiaryContainer: "0xff274e3d",
        onTertiaryContainer: "0xffc1ecd5",
        error: "0xffffb4ab",
        onError: "0xff690005",
        errorContainer: "0xff93000a",
        onErrorContainer: "0xffffdad6",
        background: "0xff14140c",
        onBackground: "0xffe7e2d5",
        surface: "0xff14140c",
        onSurface: "0xffe7e2d5",
        surfaceVariant: "0xff49473a",
        onSurfaceVariant: "0xffe7e2d5",
        inverseSurface: "0xffe7e2d5",
        inverseOnSurface: "0xff323128",
        outline: "0xff949181",
        outlineVariant: "0xff49473a",
        shadow: "0xff000000",
        scrim: "0xff000000",
        inversePrimary: "0xff666014",
        surfaceTint: "0xffd1c973"
      }
    },
    {
      light: {
        bg: "https://i2.100024.xyz/2024/01/13/qrnuwt.webp",
        bgMask: "0x50ffffff",
        primary: "0xFF2B6C00",
        onPrimary: "0xFFFFFFFF",
        primaryContainer: "0xFFA6F779",
        onPrimaryContainer: "0xFF082100",
        secondary: "0xFF55624C",
        onSecondary: "0xFFFFFFFF",
        secondaryContainer: "0xFFD9E7CA",
        onSecondaryContainer: "0xFF131F0D",
        tertiary: "0xFF386666",
        onTertiary: "0xFFFFFFFF",
        tertiaryContainer: "0xFFBBEBEB",
        onTertiaryContainer: "0xFF002020",
        error: "0xFFBA1A1A",
        onError: "0xFFFFFFFF",
        errorContainer: "0xFFFFDAD6",
        onErrorContainer: "0xFF410002",
        background: "0xFFFDFDF5",
        onBackground: "0xFF1A1C18",
        surface: "0xFFFDFDF5",
        onSurface: "0xFF1A1C18",
        surfaceVariant: "0xFFE0E4D6",
        onSurfaceVariant: "0xFF1A1C18",
        inverseSurface: "0xFF2F312C",
        onInverseSurface: "0xFFF1F1EA",
        outline: "0xFF74796D",
        outlineVariant: "0xFFC3C8BB",
        shadow: "0xFF000000",
        scrim: "0xFF000000",
        inversePrimary: "0xFF8CDA60",
        surfaceTint: "0xFF2B6C00"
      },
      dark: {
        bg: "https://i2.100024.xyz/2024/01/13/qrc37o.webp",
        bgMask: "0x50000000",
        primary: "0xFF8CDA60",
        onPrimary: "0xFF133800",
        primaryContainer: "0xFF1F5100",
        onPrimaryContainer: "0xFFA6F779",
        secondary: "0xFFBDCBAF",
        onSecondary: "0xFF283420",
        secondaryContainer: "0xFF3E4A35",
        onSecondaryContainer: "0xFFD9E7CA",
        tertiary: "0xFFA0CFCF",
        onTertiary: "0xFF003737",
        tertiaryContainer: "0xFF1E4E4E",
        onTertiaryContainer: "0xFFBBEBEB",
        error: "0xFFFFB4AB",
        errorContainer: "0xFF93000A",
        onError: "0xFF690005",
        onErrorContainer: "0xFFFFDAD6",
        background: "0xFF1A1C18",
        onBackground: "0xFFE3E3DC",
        outline: "0xFF8D9286",
        onInverseSurface: "0xFF1A1C18",
        inverseSurface: "0xFFE3E3DC",
        inversePrimary: "0xFF2B6C00",
        shadow: "0xFF000000",
        surfaceTint: "0xFF8CDA60",
        outlineVariant: "0xFF43483E",
        scrim: "0xFF000000",
        surface: "0xFF1A1C18",
        onSurface: "0xFFC7C7C0",
        surfaceVariant: "0xFF43483E",
        onSurfaceVariant: "0xFFC7C7C0"
      }
    }
  ]
};
